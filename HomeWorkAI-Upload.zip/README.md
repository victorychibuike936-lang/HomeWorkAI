# HomeWork AI

Android starter project for a student homework assistant.

App name: HomeWork AI
Developer: Chibuike Victory
Tagline: Faith is my foundation, technology is my tool.

This source project includes an offline, rule-based study helper and a basic
online-search handoff placeholder. It does not bundle a large language model.
For genuine offline generative AI, add a compatible model file and native
inference runtime; neither is included in this starter.

Build with a compatible Android SDK, Java 11, Gradle 7.5 and Android Gradle
Plugin 7.3.1. SDK Build Tools 30.0.3 are normally required by this plugin.
