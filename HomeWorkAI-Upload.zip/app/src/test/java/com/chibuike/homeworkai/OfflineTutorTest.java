package com.chibuike.homeworkai;
import org.junit.Test;
import static org.junit.Assert.*;
public class OfflineTutorTest {
    @Test public void filteringHasDefinition() {
        assertTrue(OfflineTutor.reply("Computer Studies", "Define filtering").contains("displaying"));
    }
}
