Add reviewed offline lesson content here.
