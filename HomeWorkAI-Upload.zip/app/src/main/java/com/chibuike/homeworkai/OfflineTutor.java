package com.chibuike.homeworkai;

public final class OfflineTutor {
    private OfflineTutor() {}

    public static String reply(String subject, String question) {
        String q = question.toLowerCase();
        if (q.contains("define") || q.contains("what is")) {
            if (q.contains("filter")) return "Filtering means displaying only the data that meets selected conditions.";
            if (q.contains("sort")) return "Sorting means arranging data in a chosen order, such as ascending or descending.";
            if (q.contains("photosynthesis")) return "Photosynthesis is the process by which green plants use light energy, water and carbon dioxide to make food and release oxygen.";
            if (q.contains("density")) return "Density is mass per unit volume. Its SI unit is kg/m³.";
            if (q.contains("fraction")) return "A fraction represents part of a whole. Its numerator is above the line and its denominator is below.";
            if (q.contains("conductor")) return "A conductor allows heat or electric current to pass through it easily.";
        }
        if (q.contains("2 + 2") || q.contains("2+2")) return "2 + 2 = 4. Add two items to two more items to get four.";
        if (q.contains("area") && q.contains("rectangle")) return "Area of a rectangle = length × width. Multiply the length by the width.";
        if (q.contains("photosynthesis")) return "Plants use light energy, water and carbon dioxide to make glucose; oxygen is released.";
        return "I can help with " + subject + ". Try asking for a definition, a formula, or a step-by-step explanation. This starter uses a small offline knowledge base, not a full AI language model.";
    }
}
