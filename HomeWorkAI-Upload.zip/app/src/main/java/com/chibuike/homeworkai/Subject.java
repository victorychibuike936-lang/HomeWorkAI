package com.chibuike.homeworkai;
public enum Subject {
    GENERAL, MATHEMATICS, BASIC_SCIENCE, ENGLISH, COMPUTER_STUDIES
}
