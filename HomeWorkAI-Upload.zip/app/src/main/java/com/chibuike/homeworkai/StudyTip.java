package com.chibuike.homeworkai;
public final class StudyTip {
    private StudyTip() {}
    public static String dailyTip() {
        return "Read the question carefully, identify what is given, then solve one step at a time.";
    }
}
