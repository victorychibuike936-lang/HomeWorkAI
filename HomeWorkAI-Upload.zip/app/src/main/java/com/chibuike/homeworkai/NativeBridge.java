package com.chibuike.homeworkai;
public class NativeBridge {
    public native String message();
}
