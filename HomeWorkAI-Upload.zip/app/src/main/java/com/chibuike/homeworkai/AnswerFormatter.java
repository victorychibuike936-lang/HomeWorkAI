package com.chibuike.homeworkai;
public final class AnswerFormatter {
    private AnswerFormatter() {}
    public static String format(String subject, String answer) {
        return "Subject: " + subject + "\n\nExplanation:\n" + answer;
    }
}
