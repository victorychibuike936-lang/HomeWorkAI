package com.chibuike.homeworkai;
public final class QuestionValidator {
    private QuestionValidator() {}
    public static boolean isValid(String text) {
        return text != null && !text.trim().isEmpty() && text.trim().length() <= 2000;
    }
}
