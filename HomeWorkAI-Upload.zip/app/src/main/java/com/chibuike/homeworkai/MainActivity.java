package com.chibuike.homeworkai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.text.InputType;

public class MainActivity extends Activity {
    private LinearLayout root;
    private EditText question;
    private TextView answer;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        showHome();
    }

    private TextView label(String text, int size) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(Color.WHITE);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    private void base() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(24, 30, 24, 24);
        root.setBackgroundColor(Color.rgb(12, 18, 35));
    }

    private void showHome() {
        base();
        root.addView(label("HomeWork AI", 32));
        root.addView(label("Faith is my foundation, technology is my tool.", 14));
        root.addView(label("Learn • Understand • Improve", 16));
        Button start = new Button(this);
        start.setText("GET STARTED");
        start.setOnClickListener(v -> showTutor());
        root.addView(start);
        root.addView(label("Developed by Chibuike Victory", 12));
        setContentView(root);
    }

    private void showTutor() {
        base();
        root.addView(label("Ask HomeWork AI", 26));
        Spinner subjects = new Spinner(this);
        String[] choices = {"General", "Mathematics", "Basic Science", "English", "Computer Studies"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
            android.R.layout.simple_spinner_dropdown_item, choices);
        subjects.setAdapter(adapter);
        root.addView(subjects);
        question = new EditText(this);
        question.setHint("Type your homework question...");
        question.setTextColor(Color.WHITE);
        question.setHintTextColor(Color.LTGRAY);
        question.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(question, new LinearLayout.LayoutParams(-1, 130));
        Button ask = new Button(this);
        ask.setText("GET HELP");
        answer = label("Your explanation will appear here.", 16);
        ask.setOnClickListener(v -> {
            String q = question.getText().toString().trim();
            if (q.isEmpty()) {
                answer.setText("Type a question first.");
            } else {
                answer.setText(OfflineTutor.reply(subjects.getSelectedItem().toString(), q));
            }
        });
        Button back = new Button(this);
        back.setText("HOME");
        back.setOnClickListener(v -> showHome());
        root.addView(ask);
        root.addView(answer);
        root.addView(back);
        setContentView(root);
    }
}
