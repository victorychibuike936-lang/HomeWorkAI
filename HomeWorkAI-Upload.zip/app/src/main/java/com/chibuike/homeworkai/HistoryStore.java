package com.chibuike.homeworkai;
import android.content.Context;
import android.content.SharedPreferences;
public final class HistoryStore {
    private final SharedPreferences prefs;
    public HistoryStore(Context context) {
        prefs = context.getSharedPreferences("homework_history", Context.MODE_PRIVATE);
    }
    public void saveLastQuestion(String value) {
        prefs.edit().putString("last_question", value).apply();
    }
    public String getLastQuestion() {
        return prefs.getString("last_question", "");
    }
}
