Launcher icon placeholder directory.
