#include <jni.h>
extern "C" JNIEXPORT jstring JNICALL
Java_com_chibuike_homeworkai_NativeBridge_message(JNIEnv* env, jobject) {
    return env->NewStringUTF("HomeWork AI native module is ready.");
}
