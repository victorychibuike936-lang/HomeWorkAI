# Online mode
The starter does not send student questions to a server. Add a trusted backend
before implementing online AI. Do not place API keys inside the APK.
