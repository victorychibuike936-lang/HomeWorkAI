# Changelog
1.0 - Initial HomeWork AI starter project.
