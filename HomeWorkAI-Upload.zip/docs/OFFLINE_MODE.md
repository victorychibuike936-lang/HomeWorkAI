# Offline mode
OfflineTutor.java contains a small rule-based set of explanations. It is not a
generative AI model. Expand it with verified curriculum content or integrate a
compatible on-device inference engine and model after testing device memory and speed.
