# Student safety and privacy
Do not collect unnecessary personal information. Do not embed private API keys in
the app. Have a trusted adult review online services and privacy settings.
