# Project structure
This is a newly authored HomeWork AI starter, not a copy of the TikTok creator's source.
The visible video frame showed 22 directories and 45 files. This starter focuses on
working Android source and a small offline knowledge base; it does not fabricate
the original model binaries or JNI runtime.
