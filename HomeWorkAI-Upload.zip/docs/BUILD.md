# Build
Use Java 11, Gradle 7.5 and an Android SDK. Android Gradle Plugin 7.3.1 generally
requires Android Build Tools 30.0.3. Set local.properties sdk.dir to your SDK path.
Then run: gradle assembleDebug
