Gradle wrapper configuration directory.
